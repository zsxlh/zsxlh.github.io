<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>随机选择器与报名</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
    }
    #random-choice {
      font-size: 24px;
      font-weight: bold;
    }
    .option {
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <h1>随机选择器与报名</h1>
  <p>点击下面的按钮，从选项中随机选择一个：</p>
  <button onclick="chooseRandomOption()">随机选择</button>
  <p id="random-choice"></p>

  <h2>选项与报名</h2>
  <div id="options-container"></div>

  <script>
    async function loadOptions() {
      const response = await fetch("/options");
      const data = await response.json();
      return data.options;
    }

    function chooseRandomOption(options) {
      const randomIndex = Math.floor(Math.random() * options.length);
      const randomChoice = options[randomIndex];
      document.getElementById("random-choice").innerText = "随机选择的选项是：" + randomChoice;
    }

    async function registerOption(event, option) {
      event.preventDefault();
      const name = event.target.elements.name.value;
      if (!name) {
        alert("请输入您的名字");
        return;
      }

      const formData = new FormData();
      formData.append("option", option);
      formData.append("name", name);

      const response = await fetch("https://flaskselectorapp.azurewebsites.net/register", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        alert(data.message);
        event.target.elements.name.value = "";
        loadRegistrations();
      } else {
        alert("报名失败，请稍后再试");
      }
    }

    function createOptionForm(option) {
      const form = document.createElement("form");
      form.onsubmit = (event) => registerOption(event, option);

      const label = document.createElement("label");
      label.innerText = option + ": ";
      form.appendChild(label);

      const input = document.createElement("input");
      input.type = "text";
      input.name = "name";
      input.placeholder = "输入您的名字";
      form.appendChild(input);

      const button = document.createElement("button");
      button.type = "submit";
      button.innerText = "报名";
      form.appendChild(button);

      return form;
    }

    function createOption(option) {
      const optionElement = document.createElement("div");
      optionElement.className = "option";
      optionElement.id = "option-" + option;

      const title = document.createElement("h3");
      title.innerText = option;
      optionElement.appendChild(title);

      const form = createOptionForm(option);
      optionElement.appendChild(form);

      const registeredNames = document.createElement("ul");
      registeredNames.className = "registered-names";
      optionElement.appendChild(registeredNames);

      return optionElement;
    }

    async function renderOptions() {
      const options = await loadOptions();
      const optionsContainer = document.getElementById("options-container");
      optionsContainer.innerHTML = "";
      options.forEach(option => {
        const optionElement = createOption(option);
        optionsContainer.appendChild(optionElement);
      });
    }

    async function loadRegistrations() {
  const response = await fetch("https://flaskselectorapp.azurewebsites.net/registrations");
  const data = await response.json();
  const registrationsMap = data.reduce((acc, reg) => {
    if (!acc[reg.option]) {
      acc[reg.option] = [];
    }
    acc[reg.option].push(reg.name);
    return acc;
  }, {});

  const options = await loadOptions();
  options.forEach(option => {
    const optionElement = document.getElementById("option-" + option);
    const registeredNames = optionElement.querySelector(".registered-names");
    registeredNames.innerHTML = "";

    if (registrationsMap[option]) {
      registrationsMap[option].forEach(name => {
        registeredNames.innerHTML += "<li>" + name + "</li>";
      });
    }
  });
}

async function init() {
  await renderOptions();
  loadRegistrations();
}

init();
  </script>
</body>
</html>
```